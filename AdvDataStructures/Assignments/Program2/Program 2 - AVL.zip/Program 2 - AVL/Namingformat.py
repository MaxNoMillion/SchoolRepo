# should not contain sytax error
myName = 'Andrew Steen'
myTechID = '10268080'
myTechEmail = 'ams128' #only your email id omit @latech.edu
